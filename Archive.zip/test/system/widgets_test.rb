require "application_system_test_case"

class WidgetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit widgets_url
  #
  #   assert_selector "h1", text: "Widget"
  # end
end
