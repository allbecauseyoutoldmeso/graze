class Widget < ApplicationRecord
end
